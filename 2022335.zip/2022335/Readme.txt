The game is inspired from the game given in the project and has the following additions:
1. The cherries can be bought though real life currency. (Bonus)
2. The platforms are limited and we have several number of levels.
3. The project submitted by Saarthak Saxeena is largely his effort while this project is COMPLETELY Mine.
4.The project doesnt require alot of installation and works without the pom.xml file but it is included just in case.
5. I have tried to keep everything neat , clean and organized with all the images and media used inside the resources folder.
