package com.example.stick;

public class CherryController {

}
